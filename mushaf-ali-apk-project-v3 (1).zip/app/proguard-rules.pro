# Keep JavaScript interface methods for WebView bridge
-keepclassmembers class com.mushafali.quran.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
